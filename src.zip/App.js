
// warring 멘트 제거
/*eslint-disable*/


import logo from './logo.svg';
import './App.css';
import { useState, useTransition } from 'react';

function App() {

    // let post = '승승이다';
    let [글제목, 글제목변경] = useState(['남자 코트 추천', '혼성 코트 추천' , '여자 코트 추천', '지성 코트 추천']);
    let [LikeCount, 한글] = useState([0,0,0,0]);
    let [modal, setModel] = useState(false);
    let [title, setTitle] = useState(0);



    return (
        <div className="App">
            <div className="black-nav">
                <h4>post</h4>
            </div>
            {/* <div className='list'>
                <h4>{글제목[0]} <span onClick={ ()=>{한글(LikeCount + 1)}}>👍</span> {LikeCount} </h4>
                <p>2월 17일 발행</p>
            </div>
            <div className='list'>
                <h4>{글제목[1]}  
                    </h4>
                <p>2월 17일 발행</p>
            </div>
            <div className='list'>
                <h4 onClick={()=>{ setModel(!modal) }}>{글제목[2]}</h4>
                <p>2월 17일 발행</p>
            </div> */}

            {
                글제목.map(function(index, i){
                    return (
                        <div className='list' key={i}>
                            <h4 onClick={()=>{ setModel(true); setTitle(i)}} >
                                { 글제목[i]} 
                                <span onClick={ ()=>{
                                    // 리액트 array 수정하는 jsx 문법
                                    let copy = [...LikeCount];
                                    copy[i] = copy[i] + 1;
                                    한글(copy);
                                    }}>👍</span> {LikeCount[i]}
                            </h4>
                            <p>2월 17일 발행</p>
                        </div>
                    )
                })
            }

{/* 
            <button onClick={()=>{setTitle(0)}}>글제목0</button>
            <button onClick={()=>{setTitle(1)}}>글제목1</button>
            <button onClick={()=>{setTitle(2)}}>글제목2</button>
            <button onClick={()=>{setTitle(3)}}>글제목3</button> */}

            {
                modal == true ? <Modal title={title} 글제목변경={글제목변경} 글제목={글제목}/> : null
            }
            
        </div>
    );
}

function 제목바꾸기(props){
    var newArray = [...props.글제목];
    // console.log(newArray);
    newArray[0] = '여차코트 추천';
    props.글제목변경( newArray );
}



function Modal(props){
    return (
        <div className='modal'>
            <h4>{ props.글제목[props.title]}</h4>
            <p>날짜</p>
            <p>상세내용</p>
            {/* <button onClick={()=> {
                // props.글제목변경()
                 
                // 제목바꾸기(props)    
                // var newArray = [...props.글제목]
                    // console.log(newArray);
                    // newArray[0] = '여차코트 추천';
                    // props.글제목변경( newArray );
            
            }}>글수정</button> */}
        </div>
    )
}





export default App;
